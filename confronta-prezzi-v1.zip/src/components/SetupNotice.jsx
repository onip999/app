export default function SetupNotice() {
  return (
    <section className="notice">
      <strong>Modalità demo</strong>
      <span>
        Supabase non è ancora collegato. L'interfaccia funziona con dati demo.
        Quando aggiungi le due variabili Vercel, userà automaticamente il database.
      </span>
    </section>
  )
}
